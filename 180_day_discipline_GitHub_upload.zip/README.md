# 180 Day Discipline

A simple personal 180-day discipline tracker.

- Day 1: 10 August 2026
- Day 180: 5 February 2027
- Body / Mind / Skill / YouTube
- Daily progress, streaks, history and Today's Win
- Data is stored locally in the browser

## GitHub Pages

Repository → Settings → Pages → Deploy from a branch → `main` → `/ (root)` → Save.

After deployment, open the Pages URL in Chrome and choose **Add to Home screen / Install app**.
